export default function (plop) {
  plop.setGenerator("create", {
    description: "Select what to create (Component, Test, Storybook, etc.)",
    prompts: [
      {
        type: "list",
        name: "type",
        message: "What would you like to create?",
        choices: [
          "Component", // ایجاد کامپوننت
          "Service", // ایجاد سرویس
          "Hook", // ایجاد هوک
          "Store", // ایجاد استور (برای مدیریت وضعیت)
          "Context", // ایجاد context در React
          "Utility", // ایجاد فایل‌های utility
          "API Types", // ایجاد تایپ‌های API
          "Test", // ایجاد فایل تست
          "Storybook", // ایجاد فایل استوریبوک
        ],
      },
      {
        type: "input",
        name: "name",
        message: "Enter the component/service name:",
        when: (answers) =>
          answers.type === "Component" ||
          answers.type === "Service" ||
          answers.type === "Hook" ||
          answers.type === "Store"||
          answers.type === 'API Types'||
          answers.type === 'Test', // برای کامپوننت و سرویس فعال است
        validate: function (value) {
          if (/.+/.test(value)) {
            return true;
          } else {
            return "Name is required.";
          }
        },
      },
      {
        type: "list",
        name: "storeType",
        message: "Choose a store type:",
        choices: ["Redux Toolkit", "Context API"],
        when: (answers) => answers.type === "Store", // فقط برای استور فعال است
      },
      {
        type: 'list',
        name: 'testType',
        message: 'What type of test would you like to create?',
        choices: ['Unit Test', 'Integration Test', 'End-to-End Test'],
        when: (answers) => answers.type === "Test", // فقط برای استور فعال است
      },
      {
        type: "input",
        name: "initialState",
        message: "Enter the initial state for the hook (optional):",
        when: (answers) => answers.type === "Hook", // فقط برای هوک فعال است
      },
      {
        type: "confirm",
        name: "createTest",
        message: "Would you like to create a test file?",
        default: true,
        when: (answers) => answers.type === "Component", // فقط برای کامپوننت فعال است
      },
      {
        type: "confirm",
        name: "createStorybook",
        message: "Would you like to create a storybook file?",
        default: true,
        when: (answers) => answers.type === "Component", // فقط برای کامپوننت فعال است
      },
      {
        type: "confirm",
        name: "createApi",
        message: "Would you like to create API types?",
        default: true,
        when: (answers) => answers.type === "API Types", // فقط برای API Types فعال است
      },
      {
        type: 'input',
        name: 'responseType',
        message: 'Enter the response type for the API (e.g., "User", "Product"):',
        when: (answers) => answers.type === 'API Types',
        validate: function (value) {
          if ((/.+/).test(value)) {
            return true;
          } else {
            return 'Response type is required.';
          }
        },
      },
      {
        type: "input",
        name: "apiEndpoint",
        message: "Enter the API endpoint or Swagger URL:",
        when: (answers) => answers.type === "API Types", // فقط برای API Types فعال است
      },
    ],
    actions: function (data) {
      const actions = [];

      // ایجاد کامپوننت
      if (data.type === "Component") {
        actions.push({
          type: "add",
          path: "src/components/{{pascalCase name}}/{{pascalCase name}}.tsx",
          templateFile: "automation/plop-templates/Component.tsx.hbs",
        });
        actions.push({
          type: "add",
          path: "src/components/{{pascalCase name}}/index.ts",
          templateFile: "automation/plop-templates/Index.ts.hbs",
        });
      }

      // ایجاد سرویس
      if (data.type === "Service") {
        actions.push({
          type: "add",
          path: "src/services/{{pascalCase name}}Service.ts",
          templateFile: "automation/plop-templates/Service.ts.hbs",
        });
      }

      // ایجاد هوک
      if (data.type === "Hook") {
        actions.push({
          type: "add",
          path: "src/hooks/{{camelCase name}}.ts",
          templateFile: "automation/plop-templates/Hook.ts.hbs",
        });
      }

      if (data.storeType === "Redux Toolkit") {
        actions.push({
          type: "add",
          path: "src/stores/{{pascalCase name}}Slice.ts",
          templateFile: "automation/plop-templates/StoreRedux.ts.hbs",
        });
        actions.push({
          type: "add",
          path: "src/stores/{{pascalCase name}}Config.ts",
          templateFile: "automation/plop-templates/StoreConfig.ts.hbs",
        });
      }

      if (data.storeType === "Context API") {
        actions.push({
          type: "add",
          path: "src/stores/{{pascalCase name}}Context.ts",
          templateFile: "automation/plop-templates/StoreContext.ts.hbs",
        });
      }
      // ایجاد تایپ‌های API
      if (data.type === "API Types") {
        actions.push({
          type: "add",
          path: "src/types/api/{{pascalCase apiEndpoint}}.ts",
          templateFile: "automation/plop-templates/ApiTypes.ts.hbs",
        });
      }
      // ایجاد تست
      if (data.createTest) {
        actions.push({
          type: "add",
          path: "src/tests/{{pascalCase name}}.test.tsx",
          templateFile: "automation/plop-templates/Component.test.tsx.hbs",
        });
      }

      // تست یونیت
      if (data.testType === 'Unit Test') {
        actions.push({
          type: 'add',
          path: `src/tests/unit/${data.name}.test.ts`,
          templateFile: 'plop-templates/unitTest.hbs',
        });
      }

      // تست یکپارچگی
      if (data.testType === 'Integration Test') {
        actions.push({
          type: 'add',
          path: `src/tests/integration/${data.name}.test.ts`,
          templateFile: 'plop-templates/integrationTest.hbs',
        });
      }

      // تست انتهایی
      if (data.testType === 'End-to-End Test') {
        actions.push({
          type: 'add',
          path: `src/tests/e2e/${data.name}.test.ts`,
          templateFile: 'plop-templates/e2eTest.hbs',
        });
      }

      // ایجاد استوریبوک
      if (data.createStorybook) {
        actions.push({
          type: "add",
          path: "src/components/{{pascalCase name}}/{{pascalCase name}}.stories.tsx",
          templateFile: "automation/plop-templates/Component.stories.tsx.hbs",
        });
      }

      // ایجاد تایپ‌های API
      if (data.createApi) {
        actions.push({
          type: "add",
          path: "src/types/api/{{pascalCase apiEndpoint}}.ts",
          templateFile: "automation/plop-templates/ApiTypes.ts.hbs",
        });
      }

      return actions;
    },
  });
}
