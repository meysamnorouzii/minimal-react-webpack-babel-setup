import '@testing-library/jest-dom/jest-globals';
import '@testing-library/jest-dom';
console.log('jest.setup.ts loaded');
