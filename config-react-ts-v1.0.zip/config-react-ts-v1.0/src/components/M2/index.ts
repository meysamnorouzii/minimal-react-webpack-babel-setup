// src/components/M2/index.ts

export { default } from './M2';
