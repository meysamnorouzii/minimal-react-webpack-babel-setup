import React from 'react';
import { Story, Meta } from '@storybook/react';
import M2 from './M2';

export default {
  title: 'Components/M2',
  component: M2,
} as Meta;

const Template: Story = (args) => <M2 {...args} />;

export const Default = Template.bind({});
Default.args = {
  // مقادیر پیش‌فرض
};
