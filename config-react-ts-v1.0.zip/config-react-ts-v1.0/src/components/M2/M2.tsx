import React from 'react';

interface M2Props {
  // تعریف props
}

const M2: React.FC<M2Props> = () => {
  return <div>M2 Component</div>;
};

export default M2;
