export enum AllUrl {
    base = "/",
  }
  