// Pro.ts

export interface ProRequest {
  // تعریف تایپ‌های ورودی برای درخواست‌ها
  // به عنوان مثال:
  // userId: number;
}

export interface ProResponse {
  // تعریف تایپ‌های پاسخ برای API
  // به عنوان مثال:
  // data: Array<YourDataType>;
}

// تایپ کل API
export type ProAPI = {
  request: ProRequest;
  response: ProResponse;
};
