import { render, screen } from '@testing-library/react';
import M2 from '../components/M2';
import '@testing-library/jest-dom';

describe('M2 Component', () => {
  it('renders correctly', () => {
    render(<M2 />);
    expect(screen.getByText(/M2 Component/i)).toBeInTheDocument();
  });
});
