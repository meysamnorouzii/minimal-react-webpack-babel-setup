import axios from 'axios';

class M3Service {
  private apiUrl: string;

  constructor(apiUrl: string) {
    this.apiUrl = apiUrl;
  }

  // متد برای دریافت اطلاعات
  async get(endpoint: string) {
    try {
      const response = await axios.get(`${this.apiUrl}/${endpoint}`);
      return response.data;
    } catch (error) {
      throw new Error('Error fetching data');
    }
  }

  // متد برای ذخیره اطلاعات
  async save(endpoint: string, data: any) {
    try {
      const response = await axios.post(`${this.apiUrl}/${endpoint}`, data);
      return response.data;
    } catch (error) {
      throw new Error('Error saving data');
    }
  }

  // متد برای حذف اطلاعات
  async delete(endpoint: string) {
    try {
      const response = await axios.delete(`${this.apiUrl}/${endpoint}`);
      return response.data;
    } catch (error) {
      throw new Error('Error deleting data');
    }
  }

  // متد برای بارگذاری اطلاعات
  async load(endpoint: string) {
    try {
      const response = await axios.get(`${this.apiUrl}/${endpoint}`);
      return response.data;
    } catch (error) {
      throw new Error('Error loading data');
    }
  }
}

export default new M3Service('');
