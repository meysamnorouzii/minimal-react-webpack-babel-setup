// src/services/M2.ts

interface M2Params {
  // تعریف پارامترهای ورودی (مثل ID یا هر پارامتر دیگری که نیاز دارید)
}

// بارگذاری داده‌ها
export const loadData = async (baseUrl: string, endpoint: string, params: M2Params): Promise<any> => {
  const url = `${baseUrl}${endpoint}`;

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    return await response.json();
  } catch (error) {
    console.error("Error loading data:", error);
    throw error;
  }
};

// دریافت داده‌ها
export const getData = async (baseUrl: string, endpoint: string, id: string): Promise<any> => {
  const url = `${baseUrl}${endpoint}/${id}`;

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    return await response.json();
  } catch (error) {
    console.error("Error getting data:", error);
    throw error;
  }
};

// ذخیره‌سازی داده‌ها
export const saveData = async (baseUrl: string, endpoint: string, params: M2Params): Promise<any> => {
  const url = `${baseUrl}${endpoint}`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
    return await response.json();
  } catch (error) {
    console.error("Error saving data:", error);
    throw error;
  }
};

// حذف داده‌ها
export const deleteData = async (baseUrl: string, endpoint: string, id: string): Promise<any> => {
  const url = `${baseUrl}${endpoint}/${id}`;

  try {
    const response = await fetch(url, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    return await response.json();
  } catch (error) {
    console.error("Error deleting data:", error);
    throw error;
  }
};
