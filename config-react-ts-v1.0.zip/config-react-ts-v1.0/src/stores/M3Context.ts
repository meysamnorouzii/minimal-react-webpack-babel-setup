import React, { createContext, useContext, useReducer } from 'react';

interface M3State {
  value: number;
}

const initialState: M3State = {
  value: 0,
};

type Action = { type: 'increment' } | { type: 'decrement' } | { type: 'setValue', payload: number };

const M3Context = createContext<any>(null);

const M3Reducer = (state: M3State, action: Action): M3State => {
  switch (action.type) {
    case 'increment':
      return { value: state.value + 1 };
    case 'decrement':
      return { value: state.value - 1 };
    case 'setValue':
      return { value: action.payload };
    default:
      return state;
  }
};

export const M3Provider: React.FC = ({ children }) => {
  const [state, dispatch] = useReducer(M3Reducer, initialState);

  // اینجا از براکت‌های {} استفاده می‌کنیم که Handlebars نمی‌تواند آنها را پردازش کند
  const contextValue = { state, dispatch };

  return (
    <M3Context.Provider value={contextValue}>
      {children}
    </M3Context.Provider>
  );
};

export const useM3 = () => {
  const context = useContext(M3Context);
  if (!context) {
    throw new Error('useM3 must be used within a M3Provider');
  }
  return context;
};
