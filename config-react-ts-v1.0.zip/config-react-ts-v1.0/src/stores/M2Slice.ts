import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface M2State {
  // وضعیت اولیه استور
  value: number;
}

const initialState: M2State = {
  value: 0,
};

const M2Slice = createSlice({
  name: 'M2',
  initialState,
  reducers: {
    increment: (state) => {
      state.value += 1;
    },
    decrement: (state) => {
      state.value -= 1;
    },
    setValue: (state, action: PayloadAction<number>) => {
      state.value = action.payload;
    },
  },
});

export const { increment, decrement, setValue } = M2Slice.actions;

export default M2Slice.reducer;
