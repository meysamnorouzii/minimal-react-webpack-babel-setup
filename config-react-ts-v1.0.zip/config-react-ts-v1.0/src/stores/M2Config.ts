import { configureStore } from '@reduxjs/toolkit';
import M2Reducer from './M2Slice';

const store = configureStore({
  reducer: {
    m2: M2Reducer,
  },
});

export default store;
