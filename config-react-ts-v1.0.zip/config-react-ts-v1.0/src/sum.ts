
export function Sum(a: any,b: any) {
  return a+b;
}
